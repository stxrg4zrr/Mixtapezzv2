import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import 'cover_image.dart';

/// Custom cover, else the first track's album cover, else a colored tile.
class PlaylistCover extends StatelessWidget {
  const PlaylistCover({super.key, required this.playlist, this.cacheWidth = 400});

  final Playlist playlist;
  final int cacheWidth;

  @override
  Widget build(BuildContext context) {
    final cp = playlist.coverPath;
    if (cp != null && File(cp).existsSync()) {
      return CoverImage(path: cp, cacheWidth: cacheWidth);
    }
    if (playlist.trackIds.isNotEmpty) {
      final r = context.read<LibraryStore>().ref(playlist.trackIds.first);
      if (r != null && r.album.coverPath != null) {
        return CoverImage(path: r.album.coverPath, cacheWidth: cacheWidth);
      }
    }
    final c = Color(playlist.colorValue);
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [c, const Color(0xFF111111)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Center(
        child: Icon(
          playlist.isFavorites ? Icons.favorite_rounded : Icons.queue_music_rounded,
          color: Colors.white,
          size: 44,
        ),
      ),
    );
  }
}
