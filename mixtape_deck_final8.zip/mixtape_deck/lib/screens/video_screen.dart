import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';

import '../library_store.dart';
import '../models.dart';
import '../player_controller.dart';
import '../theme.dart';

String _mmss(Duration d) {
  final m = d.inMinutes;
  final s = d.inSeconds.remainder(60);
  return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
}

class VideoScreen extends StatefulWidget {
  const VideoScreen({super.key, required this.item});

  final TrackRef item;

  @override
  State<VideoScreen> createState() => _VideoScreenState();
}

class _VideoScreenState extends State<VideoScreen> {
  static const Duration _back = Duration(seconds: 5);
  static const Duration _fwd = Duration(seconds: 10);

  late final VideoPlayerController _c;
  Timer? _hideTimer;
  bool _controls = true;
  bool _failed = false;
  bool _hasSubs = false;
  bool _subsOn = false;
  double _speed = 1.0;
  double _volume = 1.0;
  double? _drag;

  @override
  void initState() {
    super.initState();
    context.read<PlayerController>().pause();

    final sub = _findSubtitle(widget.item.track.path);
    _hasSubs = sub != null;
    _c = VideoPlayerController.file(
      File(widget.item.track.path),
      closedCaptionFile: sub == null ? null : _loadSubs(sub),
    );
    _c.addListener(() {
      if (mounted) setState(() {});
    });
    _c.initialize().then((_) {
      if (!mounted) return;
      setState(() {});
      _c.play();
      _autoHide();
    }).catchError((Object _) {
      if (mounted) setState(() => _failed = true);
    });
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    _c.dispose();
    super.dispose();
  }

  // ------------------------------------------------------------- subtitles

  String? _findSubtitle(String videoPath) {
    try {
      final dir = Directory(p.dirname(videoPath));
      final base = p.basenameWithoutExtension(videoPath).toLowerCase();
      final subs = dir.listSync().whereType<File>().where((f) {
        final e = p.extension(f.path).toLowerCase();
        return e == '.srt' || e == '.vtt';
      }).toList();
      for (final f in subs) {
        if (p.basenameWithoutExtension(f.path).toLowerCase().startsWith(base)) {
          return f.path;
        }
      }
      if (subs.length == 1) return subs.first.path;
    } catch (_) {}
    return null;
  }

  Future<ClosedCaptionFile> _loadSubs(String path) async {
    final bytes = await File(path).readAsBytes();
    final text = utf8.decode(bytes, allowMalformed: true);
    final ClosedCaptionFile f = p.extension(path).toLowerCase() == '.vtt'
        ? WebVTTCaptionFile(text)
        : SubRipCaptionFile(text);
    return f;
  }

  void _toggleSubs() {
    if (!_hasSubs) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('No subtitle file found. Put an .srt or .vtt next to the video.'),
      ));
      return;
    }
    setState(() => _subsOn = !_subsOn);
    _autoHide();
  }

  // -------------------------------------------------------------- controls

  void _autoHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 4), () {
      if (mounted && _c.value.isPlaying) setState(() => _controls = false);
    });
  }

  void _toggle() {
    final v = _c.value;
    if (v.isPlaying) {
      _c.pause();
      _hideTimer?.cancel();
    } else {
      if (v.duration > Duration.zero && v.position >= v.duration) {
        _c.seekTo(Duration.zero);
      }
      _c.play();
      _autoHide();
    }
  }

  void _jumpBy(Duration d) {
    final v = _c.value;
    var t = v.position + d;
    if (t < Duration.zero) t = Duration.zero;
    if (t > v.duration) t = v.duration;
    _c.seekTo(t);
    _autoHide();
  }

  int _indexIn(List<TrackRef> l) =>
      l.indexWhere((x) => x.track.id == widget.item.track.id);

  void _goto(int delta) {
    final l = context.read<LibraryStore>().videos;
    final i = _indexIn(l);
    final j = i + delta;
    if (i < 0 || j < 0 || j >= l.length) return;
    Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => VideoScreen(item: l[j])));
  }

  Future<void> _speedSheet() async {
    _hideTimer?.cancel();
    const options = <double>[0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
    await showModalBottomSheet<void>(
      context: context,
      builder: (sheet) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Speed',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              ),
            ),
            for (final o in options)
              ListTile(
                title: Text(o == 1.0 ? 'Normal' : '${o}x'),
                trailing: _speed == o
                    ? const Icon(Icons.check_rounded, color: kOrange)
                    : null,
                onTap: () {
                  _c.setPlaybackSpeed(o);
                  setState(() => _speed = o);
                  Navigator.pop(sheet);
                },
              ),
          ],
        ),
      ),
    );
    _autoHide();
  }

  Future<void> _audioSheet() async {
    _hideTimer?.cancel();
    const options = <MapEntry<String, double>>[
      MapEntry('Auto', 1.0),
      MapEntry('50%', 0.5),
      MapEntry('Muted', 0.0),
    ];
    await showModalBottomSheet<void>(
      context: context,
      builder: (sheet) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Audio',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              ),
            ),
            for (final o in options)
              ListTile(
                title: Text(o.key),
                trailing: _volume == o.value
                    ? const Icon(Icons.check_rounded, color: kOrange)
                    : null,
                onTap: () {
                  _c.setVolume(o.value);
                  setState(() => _volume = o.value);
                  Navigator.pop(sheet);
                },
              ),
          ],
        ),
      ),
    );
    _autoHide();
  }

  String get _audioLabel =>
      _volume == 1.0 ? 'Auto' : (_volume == 0.0 ? 'Muted' : '${(_volume * 100).round()}%');

  String get _speedLabel => _speed == 1.0 ? 'Normal' : '${_speed}x';

  // ------------------------------------------------------------------ build

  Widget _option(IconData icon, String label, String value, VoidCallback onTap) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: Colors.white, size: 30),
            const SizedBox(width: 14),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white)),
                Text(value,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w600, color: Colors.white54)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _skipButton(IconData icon, double size, VoidCallback? onTap) {
    return IconButton(
      iconSize: size,
      onPressed: onTap,
      color: Colors.white,
      disabledColor: Colors.white24,
      icon: Icon(icon),
    );
  }

  @override
  Widget build(BuildContext context) {
    final v = _c.value;
    final list = context.watch<LibraryStore>().videos;
    final idx = _indexIn(list);
    final hasPrev = idx > 0;
    final hasNext = idx >= 0 && idx < list.length - 1;
    final dur = v.duration;
    final pos = v.position;
    final frac = _drag ??
        (dur.inMilliseconds > 0
            ? (pos.inMilliseconds / dur.inMilliseconds).clamp(0.0, 1.0).toDouble()
            : 0.0);
    final shownPos = _drag != null
        ? Duration(milliseconds: (dur.inMilliseconds * _drag!).round())
        : pos;

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          setState(() => _controls = !_controls);
          if (_controls) _autoHide();
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            Center(
              child: _failed
                  ? const Text('Can\'t play this video', style: TextStyle(color: kMuted))
                  : (v.isInitialized
                      ? AspectRatio(
                          aspectRatio: v.aspectRatio,
                          child: VideoPlayer(_c),
                        )
                      : const CircularProgressIndicator(color: kOrange)),
            ),
            if (_subsOn && v.caption.text.isNotEmpty)
              Positioned(
                left: 24,
                right: 24,
                bottom: 170,
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    color: const Color(0xAA000000),
                    child: Text(
                      v.caption.text,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ),
                ),
              ),
            if (_controls && v.isInitialized) ...[
              // Dim layer so the controls are readable.
              Positioned.fill(
                child: IgnorePointer(
                  child: Container(color: const Color(0x66000000)),
                ),
              ),
              // Top bar: back, title, SUBTITLES.
              SafeArea(
                child: Align(
                  alignment: Alignment.topCenter,
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                      Expanded(
                        child: Text(
                          widget.item.track.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 17, fontWeight: FontWeight.w700),
                        ),
                      ),
                      GestureDetector(
                        onTap: _toggleSubs,
                        child: Container(
                          margin: const EdgeInsets.only(right: 14),
                          padding:
                              const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                          decoration: BoxDecoration(
                            color: _subsOn ? kChipOrange : const Color(0xFF5A5A5A),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Text('SUBTITLES',
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Centre controls: previous video, back 5s, play/pause, forward 10s, next video.
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _skipButton(Icons.skip_previous, 40,
                        hasPrev ? () => _goto(-1) : null),
                    _skipButton(Icons.replay_5, 44, () => _jumpBy(-_back)),
                    GestureDetector(
                      onTap: _toggle,
                      child: Container(
                        width: 66,
                        height: 66,
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          v.isPlaying ? Icons.pause : Icons.play_arrow,
                          color: Colors.black,
                          size: 42,
                        ),
                      ),
                    ),
                    _skipButton(Icons.forward_10, 44, () => _jumpBy(_fwd)),
                    _skipButton(Icons.skip_next, 40,
                        hasNext ? () => _goto(1) : null),
                  ],
                ),
              ),
              // Bottom: speed, audio, scrubber, time, settings.
              SafeArea(
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 40),
                        child: Align(
                          alignment: Alignment.centerRight,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _option(Icons.slow_motion_video, 'Speed', _speedLabel,
                                  _speedSheet),
                              _option(Icons.speaker, 'Audio', _audioLabel, _audioSheet),
                            ],
                          ),
                        ),
                      ),
                      SliderTheme(
                        data: SliderTheme.of(context).copyWith(
                          trackHeight: 3,
                          activeTrackColor: Colors.white,
                          inactiveTrackColor: Colors.white30,
                          thumbColor: Colors.white,
                          overlayShape: SliderComponentShape.noOverlay,
                          thumbShape:
                              const RoundSliderThumbShape(enabledThumbRadius: 8),
                        ),
                        child: Slider(
                          value: frac,
                          onChangeStart: (_) => _hideTimer?.cancel(),
                          onChanged: (x) => setState(() => _drag = x),
                          onChangeEnd: (x) {
                            _c.seekTo(Duration(
                                milliseconds: (dur.inMilliseconds * x).round()));
                            setState(() => _drag = null);
                            _autoHide();
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 8, 8),
                        child: Row(
                          children: [
                            Text(
                              _mmss(shownPos),
                              style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white),
                            ),
                            const Text('  ·  ',
                                style: TextStyle(fontSize: 18, color: Colors.white54)),
                            Text(
                              _mmss(dur),
                              style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white54),
                            ),
                            const Spacer(),
                            IconButton(
                              icon: const Icon(Icons.settings, color: Colors.white54),
                              onPressed: _speedSheet,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
            if (_controls && !v.isInitialized)
              SafeArea(
                child: Align(
                  alignment: Alignment.topLeft,
                  child: IconButton(
                    icon: const Icon(Icons.arrow_back),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
