import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../player_controller.dart';
import '../theme.dart';
import '../widgets/menus.dart';
import '../widgets/playlist_cover.dart';
import 'playlist_screen.dart';

class PlaylistsTab extends StatelessWidget {
  const PlaylistsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    final lists = store.playlists;

    return ListView(
      padding: const EdgeInsets.only(bottom: 100),
      children: [
        const SizedBox(
          height: 52,
          child: Padding(
            padding: EdgeInsets.fromLTRB(13, 2, 12, 0),
            child: SizedBox(
              height: 48,
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('All',
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
              ),
            ),
          ),
        ),
        for (final pl in lists) _PlaylistRow(playlist: pl),
        const SizedBox(height: 14),
        Center(
          child: TextButton(
            onPressed: () => showPlaylistEditor(context),
            child: const Text('+ Create Playlist',
                style: TextStyle(color: kChipOrange, fontSize: 16)),
          ),
        ),
        const SizedBox(height: 24),
        Center(
          child: Text(
            '${store.playlists.where((x) => !x.isFavorites).length} Playlists  |  '
            '${store.playlistArtistTotal} Artists  |  '
            '${store.playlistTrackTotal} Tracks',
            style: const TextStyle(color: kChipOrange, fontSize: 15),
          ),
        ),
      ],
    );
  }
}

class _PlaylistRow extends StatelessWidget {
  const _PlaylistRow({required this.playlist});

  final Playlist playlist;

  @override
  Widget build(BuildContext context) {
    final store = context.read<LibraryStore>();
    final color = Color(playlist.colorValue);
    return SizedBox(
      height: 72,
      child: InkWell(
        onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
            builder: (_) => PlaylistScreen(playlist: playlist))),
        onLongPress: () => _menu(context, store),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: SizedBox(
                  width: 60,
                  height: 60,
                  child: PlaylistCover(playlist: playlist, cacheWidth: 200),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  playlist.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 19, color: color),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _menu(BuildContext context, LibraryStore store) {
    final player = context.read<PlayerController>();
    showModalBottomSheet<void>(
      context: context,
      builder: (sheet) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.play_arrow_rounded, color: kOrange),
              title: const Text('Play'),
              onTap: () {
                Navigator.pop(sheet);
                final t = store.playlistTracks(playlist);
                if (t.isNotEmpty) player.playQueue(t, 0);
              },
            ),
            ListTile(
              leading: const Icon(Icons.edit_outlined, color: kOrange),
              title: const Text('Edit (name, color, cover)'),
              onTap: () {
                Navigator.pop(sheet);
                showPlaylistEditor(context, existing: playlist);
              },
            ),
            if (!playlist.isFavorites)
              ListTile(
                leading: const Icon(Icons.delete_outline, color: Colors.redAccent),
                title: const Text('Delete playlist'),
                onTap: () {
                  Navigator.pop(sheet);
                  store.deletePlaylist(playlist);
                },
              ),
          ],
        ),
      ),
    );
  }
}
